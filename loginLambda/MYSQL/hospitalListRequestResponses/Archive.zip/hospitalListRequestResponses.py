import pymysql.cursors
import json
import googlemaps
from datetime import datetime

# import hashlib

gmaps = googlemaps.Client(key='AIzaSyDZhjxJiq0hcDiB1MDGBAO12RBB7tBIB5k')

connection = pymysql.connect(host='dbinstance.ct0jj0n9ijm8.us-east-1.rds.amazonaws.com',
                            user='masterusername',
                            password='masterpassword',
                            db='BloodBank2',
                            charset='utf8mb4',
                            autocommit=True,
                            cursorclass=pymysql.cursors.DictCursor)
                            
def lambda_handler(event, context):
    # Collect the arguments sent by Post Request
    userName = event['userName'] 
    
    cursor = connection.cursor()
    
    sql = "Select PatientName, FirstName, LastName, UserUserName, RequestID, UserLat, UserLong FROM\
            HospitalUserRequest AS HUR INNER JOIN UserDetails AS UD \
            ON UD.UserName = HUR.UserUserName\
            INNER JOIN HospitalPostingRequest AS HPR\
            ON HPR.PatientID = HUR.PatientID\
            WHERE HospitalUserName = '" + userName + "' AND IsActive = 1\
            AND IsAcceptedByHospital = 0"
    # print sql
    
    cursor.execute(sql)
    result = cursor.fetchall()
    
    sql = "SELECT UserLat, UserLong FROM UserDetails WHERE UserName = '" + userName + "'"
    cursor.execute(sql)
    originresult = cursor.fetchall()
    
    initLat = originresult[0]['UserLat']
    initLong = originresult[0]['UserLong']
    
    origins = list()
    origins.append((initLat, initLong))
    
    print origins
    
    # result = json.dump(result)
    # print result
    # print result['UserLat']
    a = list()
    print type(result)
    for i in result:
        lat= i['UserLat']
        long= i['UserLong']
        a.append((lat,long))
    print a
    
    matrix = gmaps.distance_matrix(origins, destinations)
    # result = 'success'
    # a = []
    # for row in result:
    #     b = ["lat":row['UserLat'], "lng": row['UserLat']]
    #     a.append(b)
    #     print a
    # # print result[0]['UserLat']
    
    try:
        cursor.execute(sql)
    except Exception as e: 
        print e
        return str(e)
    else:
        return result